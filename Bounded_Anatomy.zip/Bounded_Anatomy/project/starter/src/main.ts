import 'dotenv/config';
import { mkdir, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { CodeReviewOrchestrator } from './orchestrator.js';
import { formatError, logger, ReportGenerator } from './utils/index.js';

const projectDirectory = resolve(dirname(fileURLToPath(import.meta.url)), '..');

async function main(): Promise<void> {
  const [owner, repo, prString, ...extraArgs] = process.argv.slice(2);
  if (!owner || !repo || !prString || extraArgs.length > 0) {
    console.error('Usage: npm run dev -- <owner> <repo> <positive-pr-number>');
    process.exitCode = 1;
    return;
  }

  if (!/^[1-9]\d*$/.test(prString) || !Number.isSafeInteger(Number(prString))) {
    console.error(`Invalid pull request number "${prString}". Provide a positive integer.`);
    process.exitCode = 1;
    return;
  }
  const prNumber = Number(prString);

  const anthropicAuth = Boolean(process.env.ANTHROPIC_API_KEY);
  const awsAccessKey = Boolean(process.env.AWS_ACCESS_KEY_ID);
  const awsSecretKey = Boolean(process.env.AWS_SECRET_ACCESS_KEY);
  const awsAuth = awsAccessKey && awsSecretKey;

  if (!anthropicAuth && !awsAuth) {
    console.error(
      'Authentication is not configured. Set ANTHROPIC_API_KEY, or set both ' +
      'AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY for Bedrock.'
    );
    process.exitCode = 1;
    return;
  }
  if (anthropicAuth) {
    console.log('Using Anthropic API authentication');
  } else {
    if (!process.env.AWS_REGION) {
      console.error('AWS_REGION is required when using AWS Bedrock authentication.');
      process.exitCode = 1;
      return;
    }
    process.env.CLAUDE_CODE_USE_BEDROCK = '1';
    console.log('Using AWS Bedrock authentication');
  }

  if (!process.env.ANTHROPIC_MODEL?.trim()) {
    console.error(
      'ANTHROPIC_MODEL is required. Example Anthropic API model: ' +
      'claude-sonnet-4-5-20250929; Bedrock model: ' +
      'us.anthropic.claude-sonnet-4-5-20250929-v1:0.'
    );
    process.exitCode = 1;
    return;
  }

  try {
    const orchestrator = new CodeReviewOrchestrator();
    const report = await orchestrator.reviewPullRequest(owner, repo, prNumber);
    const reportGenerator = new ReportGenerator();
    const reportsDirectory = resolve(projectDirectory, 'reports');
    const filenameBase = `${safeFilenamePart(owner)}_${safeFilenamePart(repo)}_${prNumber}`;

    await mkdir(reportsDirectory, { recursive: true });
    const files = [
      {
        extension: 'json',
        content: reportGenerator.generateJSONReport(report)
      },
      {
        extension: 'md',
        content: reportGenerator.generateMarkdownReport(report)
      },
      {
        extension: 'html',
        content: reportGenerator.generateHTMLReport(report)
      }
    ];

    for (const file of files) {
      const path = resolve(reportsDirectory, `${filenameBase}.${file.extension}`);
      await writeFile(path, file.content, 'utf8');
      console.log(`Saved ${file.extension.toUpperCase()} report: ${path}`);
    }
  } catch (error) {
    logger.error('Code review failed', { error: formatError(error), owner, repo, prNumber });
    console.error(`Code review failed: ${formatError(error)}`);
    process.exitCode = 1;
  }
}

function safeFilenamePart(value: string): string {
  return value.replace(/[^A-Za-z0-9._-]/g, '_');
}

void main();
