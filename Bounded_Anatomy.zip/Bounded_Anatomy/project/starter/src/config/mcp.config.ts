import 'dotenv/config';
import type { McpServerConfig } from '@anthropic-ai/claude-agent-sdk';

const githubEnv: Record<string, string> = {};
if (process.env.GITHUB_TOKEN) {
  githubEnv.GITHUB_PERSONAL_ACCESS_TOKEN = process.env.GITHUB_TOKEN;
}

/**
 * Model Context Protocol (MCP) server configurations
 *
 * Required MCP Servers:
 * 1. GitHub - For PR/repo operations
 * 2. ESLint - For code linting and style analysis
 *
 * Documentation:
 * - MCP Protocol: https://modelcontextprotocol.io
 * - GitHub MCP: https://github.com/github/github-mcp-server
 * - ESLint MCP: https://eslint.org/docs/latest/use/mcp
 */

export const mcpServersConfig = {
  /**
   * GitHub MCP Server
   * Provides tools for GitHub API operations
   *
   * Configuration:
   * - type: 'stdio' as const
   * - command: 'npx'
   * - args: ['-y', '@modelcontextprotocol/server-github']
   * - env: { GITHUB_PERSONAL_ACCESS_TOKEN: process.env.GITHUB_TOKEN || '' }
   *
   * Note: GITHUB_TOKEN is optional (recommended for private repos and higher rate limits).
   * The GitHub MCP server expects GITHUB_PERSONAL_ACCESS_TOKEN as the env var name.
   * We map our GITHUB_TOKEN from .env to this expected name.
   */
  github: {
    type: 'stdio',
    command: 'npx',
    args: ['-y', '@modelcontextprotocol/server-github'],
    env: githubEnv
  },

  /**
   * ESLint MCP Server
   * Provides tools for linting and code quality analysis
   *
   * Configuration:
   * - type: 'stdio' as const
   * - command: 'npx'
   * - args: ['-y', '@eslint/mcp@latest']
   * - env: {}
   */
  eslint: {
    type: 'stdio',
    command: 'npx',
    args: ['-y', '@eslint/mcp@latest'],
    env: {}
  }
} satisfies Record<string, McpServerConfig>;
