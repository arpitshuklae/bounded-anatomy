import { query } from '@anthropic-ai/claude-agent-sdk';
import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { ReviewReportJSONSchema, ReviewReportSchema } from './types/index.js';
import type { ReviewReport } from './types/report-types.js';
import { codeQualityAnalyzer, refactoringSuggester, testCoverageAnalyzer } from './agents/index.js';
import { mcpServersConfig } from './config/mcp.config.js';
import { buildOrchestratorPrompt } from './prompts/index.js';
import { RateLimiter } from './utils/rate-limiter.js';
import {
  ErrorCodes,
  formatError,
  globalRateLimiter,
  logger,
  logReviewComplete,
  logReviewStart,
  ReviewError,
  withRateLimit
} from './utils/index.js';
import type { RateLimiterConfig } from './utils/rate-limiter.js';

const projectDirectory = resolve(fileURLToPath(new URL('.', import.meta.url)), '..');

export interface OrchestratorOptions {
  model?: string;
  maxTurns?: number;
  rateLimiter?: RateLimiter;
  rateLimitConfig?: Partial<RateLimiterConfig>;
}

/**
 * Coordinates GitHub MCP access and the three specialized, read-only reviewers.
 */
export class CodeReviewOrchestrator {
  private readonly rateLimiter: RateLimiter;
  private readonly model?: string;
  private readonly maxTurns: number;

  constructor(options: OrchestratorOptions = {}) {
    this.rateLimiter = options.rateLimiter ??
      (options.rateLimitConfig ? new RateLimiter(options.rateLimitConfig) : globalRateLimiter);
    this.model = options.model ?? process.env.ANTHROPIC_MODEL;
    this.maxTurns = options.maxTurns ?? 20;
  }

  /**
   * Review a pull request using parallel subagent analysis.
   */
  async reviewPullRequest(
    owner: string,
    repo: string,
    prNumber: number
  ): Promise<ReviewReport> {
    if (
      !/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?$/.test(owner) ||
      !/^(?!\.{1,2}$)[A-Za-z0-9._-]+$/.test(repo) ||
      !Number.isSafeInteger(prNumber) ||
      prNumber < 1
    ) {
      throw new ReviewError(
        'Owner, repository, and a positive integer pull request number are required',
        ErrorCodes.INVALID_CONFIG,
        { owner, repo, prNumber }
      );
    }
    if (!this.model) {
      throw new ReviewError(
        'ANTHROPIC_MODEL must be set to a model ID supported by the selected authentication method',
        ErrorCodes.INVALID_CONFIG
      );
    }

    const startedAt = Date.now();
    logReviewStart(owner, repo, prNumber);
    let structuredOutput: unknown;
    let receivedResult = false;

    try {
      await withRateLimit(this.rateLimiter, async () => {
        for await (const message of query({
          prompt: buildOrchestratorPrompt(owner, repo, prNumber),
          options: {
            agents: {
              'code-quality-analyzer': codeQualityAnalyzer,
              'test-coverage-analyzer': testCoverageAnalyzer,
              'refactoring-suggester': refactoringSuggester
            } satisfies Record<string, AgentDefinition>,
            allowedTools: [
              'Task',
              'Agent',
              'mcp__github__get_pull_request',
              'mcp__github__get_pull_request_files',
              'mcp__github__get_file_contents'
            ],
            cwd: process.env.PROJECT_ROOT?.trim() || projectDirectory,
            maxTurns: this.maxTurns,
            mcpServers: mcpServersConfig,
            model: this.model,
            outputFormat: {
              type: 'json_schema',
              schema: ReviewReportJSONSchema
            },
            permissionMode: 'dontAsk',
            settingSources: ['project'],
            tools: ['Task', 'Agent', 'Read', 'Grep', 'Glob', 'Skill']
          }
        })) {
          if (message.type !== 'result') continue;
          receivedResult = true;
          if (message.subtype !== 'success') {
            throw new ReviewError(
              `Claude Agent SDK ended with ${message.subtype}`,
              ErrorCodes.AGENT_FAILED,
              { subtype: message.subtype }
            );
          }
          structuredOutput = message.structured_output;
        }
      }, 10000);
    } catch (error) {
      logger.error('Pull request review failed', { error: formatError(error), owner, repo, prNumber });
      throw error;
    }

    if (!receivedResult || structuredOutput === undefined) {
      throw new ReviewError(
        'The review did not return structured output',
        ErrorCodes.STRUCTURED_OUTPUT_FAILED
      );
    }

    const validation = ReviewReportSchema.safeParse(structuredOutput);
    if (!validation.success) {
      throw new ReviewError(
        'The review output did not match ReviewReportSchema',
        ErrorCodes.STRUCTURED_OUTPUT_FAILED,
        { issues: validation.error.issues }
      );
    }

    const report = validation.data;
    if (
      report.pullRequest.owner !== owner ||
      report.pullRequest.repo !== repo ||
      report.pullRequest.number !== prNumber
    ) {
      throw new ReviewError(
        'The structured review output refers to a different pull request',
        ErrorCodes.VALIDATION_FAILED,
        { expected: { owner, repo, number: prNumber }, received: report.pullRequest }
      );
    }

    const duration = Date.now() - startedAt;
    const fileCount = report.fileReviews.length;
    const completedReport: ReviewReport = {
      ...report,
      summary: {
        totalFiles: fileCount,
        overallScore: fileCount === 0
          ? 0
          : Math.round(
              report.fileReviews.reduce((sum, review) => sum + review.codeQuality.overallScore, 0) /
              fileCount
            ),
        criticalIssues: report.fileReviews.reduce(
          (sum, review) =>
            sum + review.codeQuality.issues.filter(issue => issue.severity === 'critical').length,
          0
        ),
        highPriorityTests: report.fileReviews.reduce(
          (sum, review) =>
            sum + review.testCoverage.untestedPaths.filter(
              path => path.priority === 'critical' || path.priority === 'high'
            ).length,
          0
        ),
        refactoringOpportunities: report.fileReviews.reduce(
          (sum, review) => sum + review.refactorings.suggestions.length,
          0
        )
      },
      metadata: {
        analyzedAt: new Date().toISOString(),
        duration,
        agentVersions: {
          ...report.metadata.agentVersions,
          'code-quality-analyzer': '1.0.0',
          'test-coverage-analyzer': '1.0.0',
          'refactoring-suggester': '1.0.0'
        }
      }
    };

    logReviewComplete(owner, repo, prNumber, completedReport.summary.overallScore, duration);
    return completedReport;
  }
}
