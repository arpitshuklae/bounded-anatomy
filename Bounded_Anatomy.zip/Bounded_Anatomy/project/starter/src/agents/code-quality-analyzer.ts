import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { CODE_QUALITY_ANALYZER_PROMPT } from '../prompts/code-quality-analyzer.prompt.js';

export const codeQualityAnalyzer = {
  description:
    'Reviews pull request diffs for concrete security vulnerabilities, bugs, performance problems, and maintainability issues. Use this agent for evidence-based code quality findings.',
  prompt: CODE_QUALITY_ANALYZER_PROMPT,
  tools: ['Read', 'Grep', 'Glob', 'Skill', 'mcp__github__get_file_contents'],
  model: 'inherit'
} satisfies AgentDefinition;
