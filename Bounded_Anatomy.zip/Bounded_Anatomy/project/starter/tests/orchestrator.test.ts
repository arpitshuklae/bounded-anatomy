import { describe, expect, it, vi } from 'vitest';
import { CodeReviewOrchestrator } from '../src/orchestrator.js';
import { ErrorCodes, ReviewError } from '../src/utils/error-handler.js';

describe('CodeReviewOrchestrator', () => {
  it('initializes with default options', () => {
    expect(() => new CodeReviewOrchestrator()).not.toThrow();
  });

  it('accepts custom rate limit configuration', () => {
    expect(() => new CodeReviewOrchestrator({
      rateLimitConfig: {
        maxRequestsPerMinute: 4,
        maxTokensPerMinute: 5000,
        maxConcurrent: 2
      }
    })).not.toThrow();
  });

  it('rejects invalid PR input before starting an SDK session', async () => {
    const orchestrator = new CodeReviewOrchestrator();
    await expect(orchestrator.reviewPullRequest('octocat', 'Hello-World', 0))
      .rejects.toMatchObject({ code: ErrorCodes.INVALID_CONFIG });
  });

  it('requires an explicit model before starting an SDK session', async () => {
    vi.stubEnv('ANTHROPIC_MODEL', '');
    const orchestrator = new CodeReviewOrchestrator();
    await expect(orchestrator.reviewPullRequest('octocat', 'Hello-World', 1))
      .rejects.toBeInstanceOf(ReviewError);
    vi.unstubAllEnvs();
  });
});
