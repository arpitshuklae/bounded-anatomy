import { describe, expect, it } from 'vitest';
import { zodToJsonSchema } from 'zod-to-json-schema';
import {
  CodeQualityResultSchema,
  RefactoringSuggestionSchema,
  ReviewReportJSONSchema,
  ReviewReportSchema,
  TestCoverageResultSchema
} from '../src/types/index.js';

function validReview(score = 100, coverage = 0) {
  const file = 'src/example.ts';
  return {
    pullRequest: { owner: 'octocat', repo: 'Hello-World', number: 1 },
    fileReviews: [{
      file,
      codeQuality: {
        file,
        issues: [],
        overallScore: score,
        summary: 'No confirmed quality issues.'
      },
      testCoverage: {
        file,
        hasTests: false,
        testFiles: [],
        untestedPaths: [],
        coverageEstimate: coverage,
        summary: 'No tests found for the changed file.'
      },
      refactorings: {
        file,
        suggestions: [],
        summary: 'No refactoring is necessary.'
      }
    }],
    summary: {
      totalFiles: 1,
      overallScore: score,
      criticalIssues: 0,
      highPriorityTests: 0,
      refactoringOpportunities: 0
    },
    recommendations: [],
    metadata: {
      analyzedAt: '2026-01-01T00:00:00.000Z',
      duration: 123,
      agentVersions: {}
    }
  };
}

describe('analysis result schemas', () => {
  it('accepts valid code quality, test coverage, and refactoring results', () => {
    const file = 'src/example.ts';
    expect(CodeQualityResultSchema.parse({
      file,
      issues: [{
        line: 12,
        severity: 'medium',
        category: 'bug-risk',
        description: 'A boundary case is not handled.',
        suggestion: 'Handle the empty input explicitly.'
      }],
      overallScore: 0,
      summary: 'One medium-severity concern.'
    })).toBeDefined();
    expect(TestCoverageResultSchema.parse({
      file,
      hasTests: true,
      testFiles: ['src/example.test.ts'],
      untestedPaths: [{
        type: 'edge-case',
        location: 'parseInput: empty string',
        priority: 'high',
        reasoning: 'The empty-input branch has no assertion.',
        suggestedTest: 'Pass an empty string and expect a validation error.'
      }],
      coverageEstimate: 100,
      summary: 'The behavior is fully tested.'
    })).toBeDefined();
    expect(RefactoringSuggestionSchema.parse({
      file,
      suggestions: [{
        type: 'extract-function',
        location: 'lines 10-14',
        impact: 'low',
        description: 'Extract repeated normalization into a helper.',
        before: 'const x = value.trim().toLowerCase();',
        after: 'const x = normalize(value);',
        benefits: 'Makes the normalization rule reusable.'
      }],
      summary: 'One low-impact opportunity.'
    })).toBeDefined();
  });

  it('rejects missing fields, wrong types, and invalid enum values', () => {
    expect(CodeQualityResultSchema.safeParse({ file: 42, issues: [] }).success).toBe(false);
    expect(TestCoverageResultSchema.safeParse({
      file: 'src/example.ts',
      hasTests: false,
      testFiles: [],
      untestedPaths: [{ type: 'method', priority: 'urgent' }]
    }).success).toBe(false);
    expect(RefactoringSuggestionSchema.safeParse({
      file: 'src/example.ts',
      suggestions: [{ type: 'rewrite-everything' }]
    }).success).toBe(false);
  });

  it('accepts empty collections and score boundaries in a complete report', () => {
    expect(ReviewReportSchema.parse(validReview(0, 0)).summary.overallScore).toBe(0);
    expect(ReviewReportSchema.parse(validReview(100, 100)).fileReviews[0]?.testCoverage.coverageEstimate)
      .toBe(100);
    expect(ReviewReportSchema.safeParse({
      ...validReview(),
      fileReviews: []
    }).success).toBe(true);
  });

  it('rejects invalid reports and requires all non-optional metadata', () => {
    expect(ReviewReportSchema.safeParse({
      ...validReview(),
      pullRequest: { owner: 'octocat', repo: 'Hello-World', number: '1' }
    }).success).toBe(false);
    const incomplete = validReview();
    delete (incomplete.metadata as { agentVersions?: Record<string, string> }).agentVersions;
    expect(ReviewReportSchema.safeParse(incomplete).success).toBe(false);
  });

  it('exports a JSON Schema with required fields', () => {
    const jsonSchema = zodToJsonSchema(ReviewReportSchema, { $refStrategy: 'none' }) as {
      type: string;
      properties: Record<string, unknown>;
      required: string[];
    };
    expect(jsonSchema.type).toBe('object');
    expect(jsonSchema.properties).toHaveProperty('pullRequest');
    expect(jsonSchema.required).toContain('fileReviews');
    expect(ReviewReportJSONSchema).toHaveProperty('properties');
  });
});
