import { describe, expect, it } from 'vitest';
import { ReportGenerator } from '../src/utils/report-generator.js';
import type { ReviewReport } from '../src/types/report-types.js';

const report: ReviewReport = {
  pullRequest: { owner: 'octocat', repo: 'Hello-World', number: 1 },
  fileReviews: [{
    file: 'src/<unsafe>.ts',
    codeQuality: {
      file: 'src/<unsafe>.ts',
      issues: [{
        line: 5,
        severity: 'high',
        category: 'security',
        description: '<img src=x onerror=alert(1)>',
        suggestion: 'Validate the input.'
      }],
      overallScore: 70,
      summary: 'A security issue was found.'
    },
    testCoverage: {
      file: 'src/<unsafe>.ts',
      hasTests: false,
      testFiles: [],
      untestedPaths: [{
        type: 'edge-case',
        location: 'parseInput: empty input',
        priority: 'high',
        reasoning: 'No test covers the empty value.',
        suggestedTest: 'Pass an empty value and assert a validation error.'
      }],
      coverageEstimate: 30,
      summary: 'Important edge cases are untested.'
    },
    refactorings: {
      file: 'src/<unsafe>.ts',
      suggestions: [{
        type: 'extract-function',
        location: 'lines 2-4',
        impact: 'low',
        description: 'Extract input normalization.',
        before: 'const value = raw.trim();',
        after: 'const value = normalize(raw);',
        benefits: 'Centralizes the normalization rule.'
      }],
      summary: 'One small refactoring is available.'
    }
  }],
  summary: {
    totalFiles: 1,
    overallScore: 70,
    criticalIssues: 0,
    highPriorityTests: 1,
    refactoringOpportunities: 1
  },
  recommendations: [{
    priority: 'high',
    category: 'Security',
    description: 'Validate untrusted input.',
    files: ['src/<unsafe>.ts']
  }],
  metadata: {
    analyzedAt: '2026-01-01T00:00:00.000Z',
    duration: 123,
    agentVersions: {}
  }
};

describe('ReportGenerator', () => {
  const generator = new ReportGenerator();

  it('creates valid JSON and Markdown with actionable refactoring examples', () => {
    expect(JSON.parse(generator.generateJSONReport(report))).toEqual(report);
    const markdown = generator.generateMarkdownReport(report);
    expect(markdown).toContain('src/<unsafe>.ts');
    expect(markdown).toContain('Before: `const value = raw.trim();`');
    expect(markdown).toContain('After: `const value = normalize(raw);`');
  });

  it('includes file findings in HTML and escapes untrusted content', () => {
    const html = generator.generateHTMLReport(report);
    expect(html).toContain('src/&lt;unsafe&gt;.ts');
    expect(html).toContain('&lt;img src=x onerror=alert(1)&gt;');
    expect(html).not.toContain('<img src=x onerror=alert(1)>');
    expect(html).toContain('Pass an empty value and assert a validation error.');
    expect(html).toContain('const value = normalize(raw);');
  });
});
