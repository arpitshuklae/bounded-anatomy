import { describe, expect, it, vi } from 'vitest';
import { ErrorCodes, ReviewError, withRetry, withTimeout } from '../src/utils/error-handler.js';
import { RateLimiter, withRateLimit } from '../src/utils/rate-limiter.js';

describe('error handling utilities', () => {
  it('retries failed operations with a bounded number of attempts', async () => {
    vi.spyOn(Math, 'random').mockReturnValue(0);
    let attempts = 0;
    const result = await withRetry(async () => {
      attempts += 1;
      if (attempts < 3) throw new Error('temporary failure');
      return 'ok';
    }, 2, 0);

    expect(result).toBe('ok');
    expect(attempts).toBe(3);
    vi.restoreAllMocks();
  });

  it('throws RETRY_EXHAUSTED after the configured attempts', async () => {
    await expect(withRetry(async () => {
      throw new Error('unavailable');
    }, 0, 0)).rejects.toMatchObject({
      code: ErrorCodes.RETRY_EXHAUSTED,
      metadata: { attempts: 1 }
    });
  });

  it('rejects with AGENT_TIMEOUT when the operation exceeds its deadline', async () => {
    await expect(withTimeout(
      () => new Promise(resolve => setTimeout(resolve, 30)),
      1
    )).rejects.toMatchObject({
      code: ErrorCodes.AGENT_TIMEOUT,
      metadata: { timeoutMs: 1 }
    });
  });
});

describe('RateLimiter', () => {
  it('tracks admitted requests, token use, and concurrent slots', async () => {
    const limiter = new RateLimiter({
      maxRequestsPerMinute: 2,
      maxTokensPerMinute: 1500,
      maxConcurrent: 1
    });
    await limiter.acquire(1000);

    expect(limiter.getStatus()).toMatchObject({
      activeRequests: 1,
      requestsInWindow: 1,
      tokensInWindow: 1000
    });
    expect(limiter.canProceed(100)).toBe(false);

    limiter.release();
    expect(limiter.getStatus().activeRequests).toBe(0);
    expect(limiter.canProceed(100)).toBe(true);
  });

  it('rejects a request that can never fit in the token window', async () => {
    const limiter = new RateLimiter({ maxTokensPerMinute: 500 });
    await expect(limiter.acquire(501)).rejects.toBeInstanceOf(ReviewError);
  });

  it('prunes records that have fallen outside the 60-second window', async () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date('2026-01-01T00:00:00.000Z'));
    const limiter = new RateLimiter({
      maxRequestsPerMinute: 1,
      maxTokensPerMinute: 1000,
      maxConcurrent: 1
    });
    await limiter.acquire(1000);
    limiter.release();

    vi.setSystemTime(new Date('2026-01-01T00:01:01.000Z'));
    expect(limiter.canProceed(1000)).toBe(true);
    vi.useRealTimers();
  });

  it('queues acquisitions when all concurrent slots are occupied', async () => {
    const limiter = new RateLimiter({
      maxRequestsPerMinute: 5,
      maxTokensPerMinute: 5000,
      maxConcurrent: 1
    });
    await limiter.acquire(100);
    const waiting = limiter.acquire(100);
    await Promise.resolve();
    expect(limiter.getStatus().activeRequests).toBe(1);

    limiter.release();
    await waiting;
    expect(limiter.getStatus().activeRequests).toBe(1);
    limiter.release();
  });

  it('releases the concurrent slot after the wrapped operation settles', async () => {
    const limiter = new RateLimiter();
    await expect(withRateLimit(limiter, async () => 'done', 25)).resolves.toBe('done');
    expect(limiter.getStatus().activeRequests).toBe(0);

    await expect(withRateLimit(limiter, async () => {
      throw new Error('failed');
    })).rejects.toThrow('failed');
    expect(limiter.getStatus().activeRequests).toBe(0);
  });
});
