---
description: Reviews TypeScript changes for sound types, safe narrowing, and maintainable language patterns
---

# TypeScript Patterns

Review the changed TypeScript code for correctness and maintainability. Prefer accurate types and runtime guards over casts or broad types.

## Type safety

- Avoid `any`, unsafe assertions, and non-null assertions when a type guard or a better type models the invariant.
- Narrow `unknown` at system boundaries and validate external data before use.
- Represent impossible states with discriminated unions and exhaustive `never` checks.
- Keep optional values explicit; handle `undefined` and `null` rather than assuming presence.
- Use generics only when they preserve useful relationships between inputs and outputs.

## API and async patterns

- Keep exported types and runtime validation aligned.
- Propagate asynchronous failures; do not convert failures into success-shaped defaults.
- Use `Promise.all` for independent work and preserve errors with enough context.
- Avoid mutating shared state across concurrent operations without an explicit synchronization or ownership rule.
- Use `readonly` where it protects an invariant and avoid overcomplicated type machinery.

## Output

Report only concrete issues introduced by the change. Explain the type or runtime failure, identify the affected location, and provide a practical correction. Do not report stylistic preferences as defects.
